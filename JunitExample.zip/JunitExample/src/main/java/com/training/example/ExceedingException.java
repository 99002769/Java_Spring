package com.training.example;

public class ExceedingException extends Exception {

	public ExceedingException()
	{
		super();
	}

	public ExceedingException(String message)
	{
		super(message);
	}
}
