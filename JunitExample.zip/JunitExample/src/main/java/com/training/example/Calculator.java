package com.training.example;

public class Calculator {

	public int sum(int x,int y)
	{
		
		return x+y;
	}
	

	public int difference(int x,int y)
	{
		
		return x-y;
	}
	
	
	public int division(int x,int y)
	{
		
		return x/y;
	}
	
}


