package com.training.example;

public class NegativeValueException extends RuntimeException {

	
	public NegativeValueException() {
		// TODO Auto-generated constructor stub
		super();
		
		
	}
	
	public NegativeValueException (String message)
	{
		super(message);
	}

}
