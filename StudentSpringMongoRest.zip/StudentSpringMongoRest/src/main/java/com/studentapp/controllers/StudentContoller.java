package com.studentapp.controllers;

import com.studentapp.service.StudentService;

@RestController
@RequsetMapping("/student-api")
public class StudentContoller {
	
	@Autowired
	StudentService studentService;
	
	
	public StudentController()
	{}
	
	@PostMapping("/students")
	Student addStudent(@RequestBody Student student)
	{
		
	}
	
	

}
