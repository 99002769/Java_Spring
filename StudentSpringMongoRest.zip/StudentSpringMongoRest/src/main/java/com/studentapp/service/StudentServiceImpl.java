package com.studentapp.service;

import java.util.List;

import com.studentapp.model.Student;

public class StudentServiceImpl implements StudentService {

	@Override
	public Student deleteStudent(int studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudentById(int studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getStudentByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getStudentByDepartment(String department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findByAge(int age) {
		// TODO Auto-generated method stub
		return null;
	}

}
