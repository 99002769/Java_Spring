package com.hotelapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelookRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelookRestApiApplication.class, args);
	}

}
