package com.rmv.exceptions;

public class TooLongException extends Exception {

	public TooLongException() {
		// TODO Auto-generated constructor stub
	}

	public TooLongException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
