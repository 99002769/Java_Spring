module HotelApp {
}