package com.bookapp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bookapp.model.book;
import com.bookapp.service.BookService;

@SpringBootApplication
public class OnlineBookAppApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookAppApplication.class, args);
	}

	@Autowired
	BookService bookService;
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Display All Books");
		bookService.getAllBooks().forEach(System.out::println);
		System.out.println("List Author");
		bookService.getByAuthor("john").forEach(System.out::println);
		System.out.println("List Category");
		bookService.getByCategory("Tech").forEach(System.out::println);
		//bookService.getByCategory("Tech").
		book book = bookService.getById(3);
		System.out.println("List Id");
		System.out.println(book);
		
		
	}

}
