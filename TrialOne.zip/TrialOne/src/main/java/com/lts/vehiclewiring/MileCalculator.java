package com.lts.vehiclewiring;

import org.springframework.stereotype.Component;

@Component
public interface MileCalculator {
	public void showMileage(int km,int fuel);
	
}
