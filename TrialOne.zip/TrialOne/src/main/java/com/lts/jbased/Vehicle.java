package com.lts.jbased;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Vehicle {
	
	int vehicleId;
	String vehicleName;
	String brand;
	
	
	public int getVehicleId() {
		return vehicleId;
	}
	@Value("101")
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getVehicleName() {
		return vehicleName;
	}
	@Value("Star")
	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}
	public String getBrand() {
		return brand;
	}
	@Value("Hero")
	public void setBrand(String brand) {
		this.brand = brand;
	}
	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", vehicleName=" + vehicleName + ", brand=" + brand + "]";
	}
	

}
